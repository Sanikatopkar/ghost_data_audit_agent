"""Three extra deterministic request-intent checks beyond the public sample."""
from pathlib import Path
import sys
ROOT = next(parent for parent in Path(__file__).resolve().parents if (parent / "ghost_audit").is_dir())
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from ghost_audit.audit_classifier import AuditClassifier

CASES = [
    ("custom_delete_direct", "Please erase my account and all personal details.", True),
    ("custom_access_only", "Please send me a copy of my account data; I am not asking you to delete it.", False),
    ("custom_delete_followup", "The account was deleted last week. Please verify that no copy remains.", True),
]

def run() -> list[tuple[str, bool, bool]]:
    classifier = AuditClassifier()
    return [(case_id, classifier.authorizes_deletion(text), expected) for case_id, text, expected in CASES]

if __name__ == "__main__":
    results = run()
    for case_id, actual, expected in results:
        print(f"{case_id}: expected={expected} actual={actual}")
    raise SystemExit(0 if all(actual == expected for _, actual, expected in results) else 1)
