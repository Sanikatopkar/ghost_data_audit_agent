﻿# Evaluation report

## Public sample evaluation

The deterministic evaluator was run on the 32 public sample requests in `dataset/sample_deletion_requests.csv`, compared with `dataset/sample_output.csv`.

| Metric | Result |
|---|---:|
| Deletion status | 22 / 32 (68.75%) |
| Exact step sequence | 8 / 32 (25.00%) |
| Step accuracy | 91 / 195 (46.67%) |
| Field accuracy | 876 / 1,365 (64.18%) |

The public sample is a smoke check, not a hidden-set estimate. The solution has known gaps in resource linkage and exact step completeness; do not read this score as a claim of challenge-winning accuracy.

## Additional team-created checks

These are separate intent-classification cases and do not use the public reference answers:

| Case | Input | Expected | Actual |
|---|---|---:|---:|
| `custom_delete_direct` | “Please erase my account and all personal details.” | Deletion authorized | Pass |
| `custom_access_only` | “Please send me a copy of my account data; I am not asking you to delete it.” | Not authorized | Pass |
| `custom_delete_followup` | “The account was deleted last week. Please verify that no copy remains.” | Deletion authorized | Pass |

Command: `python evaluation/additional_cases.py` (in the submission ZIP) or `python code/evaluation/additional_cases.py` (in the project folder) (3/3 passed).

## Failures found and changes made

- The first intent rules missed common inflections such as “deleting” and multilingual “suppression.” The classifier was broadened and now recognizes all 32 public sample request texts as deletion-related.
- A broad exclusion for email changes incorrectly suppressed messages that also requested deletion. The exclusion was removed; explicit denial language remains a veto.
- Treating identity references such as `user_08` as storage resources created spurious steps. Evidence resource extraction now accepts only the challenge resource-ID families.
- Nested JSON status codes and empty snapshot tables were not interpreted. The parser now reads leaf field names such as `status_code=404` and records empty snapshot coverage.
- Multiple source aliases could produce duplicate system entries. Known service aliases are normalized.

## Remaining limitations

- OCR was not available for the 11 PNG evidence files in the full run. They were reported as reader warnings and were not used; image-only facts may therefore be missed.
- Some evidence-to-account links remain ambiguous or are not represented in participant-facing artifacts. This lowers status and exact-step accuracy, especially for account absence and secondary resource discovery.
- The output follows the required CSV schema and the full-run CLI validator accepted all 518 rows. More evidence linking and image OCR are the highest-value improvements before a final hackathon submission.

