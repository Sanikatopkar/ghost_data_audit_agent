"""Evaluate public sample cases against the supplied reference output."""
from __future__ import annotations
import json
import sys
from pathlib import Path

ROOT = next(parent for parent in Path(__file__).resolve().parents if (parent / "ghost_audit").is_dir())
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from ghost_audit.audit_engine import AuditEngine


def evaluate() -> dict:
    engine = AuditEngine(ROOT / "dataset")
    sample = engine.sample_requests
    expected = engine.sample_output.set_index("case_id")
    actual = [engine.audit_case(row.to_dict()) for _, row in sample.iterrows()]
    status_correct = 0
    sequence_correct = 0
    field_correct = 0
    field_total = 0
    step_correct = 0
    step_total = 0
    failures = []
    for result in actual:
        gold = expected.loc[result.case_id]
        got_steps = [step.as_dict() for step in result.steps]
        expected_steps = json.loads(gold.steps_json)
        status_ok = result.deletion_status == gold.deletion_status
        seq_ok = got_steps == expected_steps
        status_correct += int(status_ok)
        sequence_correct += int(seq_ok)
        width = max(len(got_steps), len(expected_steps))
        step_total += width
        step_correct += sum(1 for i in range(width) if i < len(got_steps) and i < len(expected_steps) and got_steps[i] == expected_steps[i])
        for i in range(width):
            for field in ("step_no", "phase", "system_id", "resource_id", "operation", "state", "evidence_id"):
                field_total += 1
                field_correct += int(i < len(got_steps) and i < len(expected_steps) and got_steps[i].get(field) == expected_steps[i].get(field))
        if not status_ok or not seq_ok:
            failures.append({"case_id": result.case_id, "expected_status": gold.deletion_status, "actual_status": result.deletion_status, "expected_steps": expected_steps, "actual_steps": got_steps})
    metrics = {
        "sample_cases": len(sample),
        "status_correct": status_correct,
        "status_accuracy": status_correct / len(sample) if len(sample) else 0,
        "sequence_correct": sequence_correct,
        "sequence_accuracy": sequence_correct / len(sample) if len(sample) else 0,
        "step_correct": step_correct,
        "step_total": step_total,
        "step_accuracy": step_correct / step_total if step_total else 0,
        "field_correct": field_correct,
        "field_total": field_total,
        "field_accuracy": field_correct / field_total if field_total else 0,
        "failures": failures,
    }
    return metrics


if __name__ == "__main__":
    print(json.dumps(evaluate(), indent=2, ensure_ascii=False))
