﻿# Token usage and cost report

Full-dataset run that generated the repository-root `output.csv`:

- Model provider/name: none (deterministic local Python; no LLM)
- Model calls: 0
- Input tokens: 0
- Output tokens: 0
- Total tokens: 0
- Average tokens per request: 0 across 518 requests
- Estimated total model cost: $0.00
- Estimated average model cost: $0.00 per request

The run reads the supplied participant dataset locally. No hosted model or paid inference API was called, so there are no per-model token totals beyond the zero-use total above.
