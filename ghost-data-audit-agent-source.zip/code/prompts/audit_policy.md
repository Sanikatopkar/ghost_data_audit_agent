﻿# Evidence handling and decision policy

The agent runs deterministically and does not call a language model at prediction time. It treats participant evidence as data, never as executable instructions.

1. Read the request text first. Non-deletion requests return `NOT_APPLICABLE` and no steps.
2. Resolve the request email only through exact current identity rows, historical email changes, and explicit data-catalog links that existed by `audit_at`.
3. Read the evidence manifest and parse participant files only. Ignore a file or observation dated after the case cutoff.
4. Treat workflow status and activity result fields as claims. Use them to locate records, not as sole proof that a record was removed.
5. Apply the matching action in `deletion_rules.csv`; preserve required retention and tombstone references.
6. For an incomplete case, order findings, remediation, and future verification using the challenge operation ordering. Cite current evidence for findings and leave proposed steps uncited.
7. For a complete case, emit only evidence-cited verification steps. If the account cannot be proven absent or identity matching is ambiguous, classify the case as incomplete.
8. Serialize exactly `case_id,deletion_status,steps_json` and validate row count, statuses, JSON arrays, step numbering, and ordering.
